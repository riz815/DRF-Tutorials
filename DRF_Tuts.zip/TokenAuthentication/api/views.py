from .models import Student
from .serializer import StudentSerializer

from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import BasicAuthentication,SessionAuthentication,TokenAuthentication

#Token authentication can perform by 3 ways
#1 by creating using admin panel register in settings.py rest_framework.tokenauth
# by creating using command python .\manage.py drf_create_token username
#by creating httpie by exposing an API end point
#must run pyhton manage.py migrate command to create token
#Important: token also created when a new user account created see in models.py
class STUDENTAPIVIEWSET(viewsets.ModelViewSet):
    
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    
    permission_classes = [IsAuthenticated]
    authentication_classes=[TokenAuthentication]
   