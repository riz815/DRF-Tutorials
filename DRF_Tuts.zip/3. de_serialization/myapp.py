import requests
import json
URL = "http://127.0.0.1:8000/stu_create/"

data = {
    "name":"sabiha_samreen",
    "roll": 21,
    "city":"Lahore Pakistan"
}

json_data = json.dumps(data)

r =requests.post(url=URL, data = json_data)

data =r.json()
print(data)