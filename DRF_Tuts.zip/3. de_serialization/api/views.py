from django.shortcuts import render
import io
from rest_framework.parsers import JSONParser
from .serializer import studentSerializer
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
# Create your views here.

@csrf_exempt
def studentCreate(request):
    
    if request.method == 'POST':
        json_data = request.body
        stream = io.BytesIO(json_data)
        python_data = JSONParser().parse(stream)
        serialized_Data = studentSerializer(data=python_data)
        
        if serialized_Data.is_valid():
            serialized_Data.save()
            res = {'msg':'data created successfully'}
            return JsonResponse(res)