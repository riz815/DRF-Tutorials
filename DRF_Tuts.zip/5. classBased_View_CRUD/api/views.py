from django.shortcuts import render
from .serializer import studentSerializer
from .models import Student
import io
from rest_framework.parsers import JSONParser
from django.http import JsonResponse
from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.views import View
from django.utils.decorators import method_decorator
# Create your views here.
@method_decorator(csrf_exempt, name='dispatch')
class StudentAPi(View):
    
    def get(self, request, *args, **kwargs):
        json_data = request.body
        stream = io.BytesIO(json_data)
        python_data = JSONParser().parse(stream)
        id = python_data.get('id', None)
        
        if id is not None:
            stu = Student.objects.get(id=id)
            serializer = studentSerializer(stu)
            # json_data = JSONRenderer().render(serializer.data)
            # return HttpResponse(json_data, content_type = 'application/json')
            return JsonResponse(serializer.data)
    
        stu = Student.objects.all()
        serializer = studentSerializer(stu, many= True)
        return JsonResponse(serializer.data, safe=False)
    def post(self, request, *args, **kwargs):
        json_data = request.body
        stream = io.BytesIO(json_data)
        python_data = JSONParser().parse(stream)
        serialized_Data = studentSerializer(data=python_data)
        
        if serialized_Data.is_valid():
            serialized_Data.save()
            res = {'msg':'data created successfully'}
            return JsonResponse(res)
        
    
    def put(self, request, *args, **kwargs):
        json_data = request.body
        stream = io.BytesIO(json_data)
        pyhton_Data = JSONParser().parse(stream)
        id = pyhton_Data.get('id')
        stu = Student.objects.get(id=id)
        serilaizer = studentSerializer(stu, data=pyhton_Data, partial = True)
        if serilaizer.is_valid():
            serilaizer.save()
            res = {'msg':'DAta updated'}
            return JsonResponse(res)
    

        return JsonResponse(res, safe=False)
    
    def delete(self, request, *args, **kwargs):

        json_data = request.body
        stream = io.BytesIO(json_data)
        python_data = JSONParser().parse(stream)
        id = python_data.get('id')
        
        stu = Student.objects.get(id=id)
        stu.delete()
        res = [{'id':stu.name,
               'Roll':stu.roll,
               'city':stu.city,
               
               },{
                   'msg':'data deleted',
               }]
        return JsonResponse(res, safe=False)