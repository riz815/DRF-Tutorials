from rest_framework import serializers
from .models import Student
class studentSerializer(serializers.ModelSerializer): #automatic generate fields fro  models and also create adn update methods in it
    class Meta:
        #validators can apply here
        name = serializers.CharField(read_only = True)
        model = Student
        
        fields = ['name','city','roll'] #select desired filed
        
        # fields = '__all__' #select all feilds
        
        #use here for validators
        # read_only_fields = ['name','roll']
        # extra_kwargs = {'name':{'read_only':True}} #it also used for validators
        
        #filed level validation
        
    def validate_roll(self, value):
        if value >= 200:
            raise serializers.ValidationError('seats full')
        else:
            return  value