from django.shortcuts import render
from .models import Person
from .serializer import personSerializer
from django.http import JsonResponse
# Create your views here.

def person_view(request,pk):

    person = Person.objects.get(id=pk)

    serializer = personSerializer(person)

    return JsonResponse(serializer.data)

def person_view_all(request):

    person = Person.objects.all()
    serializer = personSerializer(person, many = True)

    return JsonResponse(serializer.data, safe= False)

