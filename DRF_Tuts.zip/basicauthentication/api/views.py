from .models import Student
from .serializer import StudentSerializer

from rest_framework import viewsets
from rest_framework.permissions import IsAdminUser, IsAuthenticated,DjangoModelPermissions,AllowAny,DjangoModelPermissionsOrAnonReadOnly, IsAuthenticatedOrReadOnly
from rest_framework.authentication import BasicAuthentication,SessionAuthentication

class STUDENTAPIVIEWSET(viewsets.ModelViewSet):
    
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    
    # also can define in settings.py for all as globall
    # permission_classes = [IsAdminUser]
    # authentication_classes = [BasicAuthentication]
    
    authentication_classes = [SessionAuthentication]  # for this should add login urls in urls.py
    # permission_classes = [IsAuthenticated]  #path('auth/', include('rest_framework.urls', namespace='rest_framework')),
    # permission_classes = [IsAuthenticatedOrReadOnly]
    # permission_classes = [AllowAny]
    # permission_classes = [DjangoModelPermissions] #allow users to perform crud operation base on their permissions
    
    permission_classes = [DjangoModelPermissionsOrAnonReadOnly] # use to view all data for unauthenticated and registered users do crud operations
    
    