from django.shortcuts import render
from .models import Student
from .serializer import StudentSerializer
from rest_framework.generics import ListAPIView,ListCreateAPIView,RetrieveUpdateDestroyAPIView
from django_filters import rest_framework as filters
from rest_framework.filters import SearchFilter,OrderingFilter
# Create your views here.
   
class StudentView(ListAPIView):
    
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    
    # filter_backends = (filters.DjangoFilterBackend,)
    # filterset_fields = ('name','city')
    # filter_backends = [SearchFilter]
    # search_fields = ['name']
    # search_fields = ['^name'] # start with ^regex
    # search_fields = ['=name'] # exact match
    
    filter_backends = [OrderingFilter] #ordering recordds asc or desc
    ordering_fields = ['name']
    
    
    

    
#For Global initialization for all views
#REST_FRAMEWORK = {
#     'DEFAULT_FILTER_BACKENDS': (
#         'django_filters.rest_framework.DjangoFilterBackend',
#         ...
#     ),
# }