from rest_framework.throttling import AnonRateThrottle,UserRateThrottle

class JackThrottle(UserRateThrottle):
    
    scope = 'jack'