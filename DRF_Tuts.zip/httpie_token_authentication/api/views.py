from .models import Student
from .serializer import StudentSerializer

from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import BasicAuthentication,SessionAuthentication,TokenAuthentication

#http -f POST  http://127.0.0.1:800/studentapi/ name=nadeem roll=12 city=Lahore 'Authorization:Token 0d120881c2a2a6d883e56e7c7f2b22840256570e' 
#by using above command can get,post,put,patch and delete methods applied and test apis
class STUDENTAPIVIEWSET(viewsets.ModelViewSet):
    
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    
    permission_classes = [IsAuthenticated]
    authentication_classes=[TokenAuthentication]
   