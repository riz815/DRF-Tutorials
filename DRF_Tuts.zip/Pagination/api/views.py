from django.shortcuts import render
from .models import Student
from .serializer import StudentSerializer
from rest_framework.generics import ListAPIView
from rest_framework.pagination import PageNumberPagination, LimitOffsetPagination, CursorPagination
from .cursorpagination import Mycusrsor
# Create your views here.
   
class StudentView(ListAPIView):
    
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    
    # pagination_class = PageNumberPagination 
    # pagination_class = LimitOffsetPagination
    pagination_class = Mycusrsor
    
    