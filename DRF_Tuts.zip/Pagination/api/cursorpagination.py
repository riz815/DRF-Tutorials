from rest_framework.pagination import CursorPagination


class Mycusrsor(CursorPagination):
    
    page_size = 5
    ordering = 'name'