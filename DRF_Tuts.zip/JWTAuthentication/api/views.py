from .models import Student
from .serializer import StudentSerializer

from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import BasicAuthentication,SessionAuthentication,TokenAuthentication
from rest_framework_simplejwt.authentication import JWTAuthentication
#http -f POST  http://127.0.0.1:800/studentapi/ name=nadeem roll=12 city=Lahore 'Authorization:Token 0d120881c2a2a6d883e56e7c7f2b22840256570e' 
#by using above command can get,post,put,patch and delete methods applied and test apis
class STUDENTAPIVIEWSET(viewsets.ModelViewSet):
    
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    
    authentication_classes=[JWTAuthentication]
    permission_classes = [IsAuthenticated]
   
   #http http://127.0.0.1:8000/studentapi/ 'AUTHORIZATION:Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNjkzMjA3MzEwLCJpYXQiOjE2OTMyMDY4NTEsImp0aSI6ImMxMTI0MmNhYmY2ZTQ1MmNiYzA2ZTdjOGE4ZjAzZWU4IiwidXNlcl9pZCI6MX0.ZPmM_JEnv-twxSNtCplabK584YNCMHy46HmFmB8sp3w'
#    use the above command to get data by using JWT token