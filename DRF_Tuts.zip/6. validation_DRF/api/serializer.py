from rest_framework import serializers
from .models import Student

#validators
def start_With_uppercae(value):
    if value[0]. isupper():
        return value
    else:
        raise serializers.ValidationError('first letter must be in uppercase')
class studentSerializer(serializers.Serializer):
    name  = serializers.CharField( max_length=50, validators = [start_With_uppercae])
    roll = serializers.IntegerField()
    city = serializers.CharField(max_length=50)
    
    def create(self, validated_data):
        
        return Student.objects.create(**validated_data)
    
    def update(self, instance, validated_data): #instance hold old data
        
        instance.name = validated_data.get('name', instance.name)
        instance.city = validated_data.get('city', instance.city)
        instance.roll = validated_data.get('roll', instance.roll)
        instance.save()
        return instance
    
      # field level validation  
    def validate_roll(self, value):
        
        if value >= 200:
            raise serializers.ValidationError('Seats full')
        return value
   
   #object level validation 
    def validate(self, data):
        
        name = data.get('name')
        city = data.get('city')
        
        if name.lower() == 'rizwan' and city.lower()== 'lahore':
            
            return data
        else:
            raise serializers.ValidationError('city must be Lahore') 