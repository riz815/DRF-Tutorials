import requests
import json

# URL ="http://127.0.0.1:8000/show_data/"
# show data function
def get_data(id = None):
    data = {}
    if id is not None:
        data = {'id':id}
        
    json_data = json.dumps(data)
    r = requests.get(url=URL, data=json_data)
    data = r.json()
    print(data)
    
# get_data(1)
URL ="http://127.0.0.1:8000/post_data/"

#create data function

def create_data():
    
    data = {
        'name':'naeem',
        'roll':150,
        'city':'Lahore'
    }
    
    json_data = json.dumps(data)
    
    r = requests.post(url=URL, data= json_data)
    
    data = r.json()
    print(data)
    
create_data()

def update_Data():
     data = {
         'id':3,
        'name':'Rizwan',
        'city':'Karachi'
    }
     json_Data = json.dumps(data)
     r = requests.put(url= URL, data= json_Data)
     data = r.json()
     print(data)

# update_Data()


def delete_Data():
     data = {'id':2}
     json_Data = json.dumps(data)
     r = requests.delete(url= URL, data= json_Data)
     data = r.json()
     print(data)

# delete_Data()