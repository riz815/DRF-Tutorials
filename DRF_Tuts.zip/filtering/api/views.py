from django.shortcuts import render
from .models import Student
from .serializer import StudentSerializer
from rest_framework.generics import ListAPIView,ListCreateAPIView,RetrieveUpdateDestroyAPIView
# Create your views here.
   
class StudentView(ListAPIView):
    
    # queryset = Student.objects.filter(passby = 'teacher1') #its easy way to filter record
    queryset = Student.objects.all()
    
    serializer_class = StudentSerializer
    
    def get_queryset(self):
        user = self.request.user
        return Student.objects.filter(passby = user)    #filter data base on user
    
    #username and password
    #teacher1 = Pakistan@1122
    #teacher2 = Pakistan@2233
    