from .models import Student
from .serializer import StudentSerializer
from rest_framework.generics import ListAPIView,CreateAPIView,RetrieveAPIView,DestroyAPIView,UpdateAPIView,ListCreateAPIView,RetrieveUpdateDestroyAPIView

class LSTUDENT(ListCreateAPIView):
    
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    
    
class RUDSTUDENT(RetrieveUpdateDestroyAPIView):
    
    queryset = Student.objects.all()
    serializer_class = StudentSerializer